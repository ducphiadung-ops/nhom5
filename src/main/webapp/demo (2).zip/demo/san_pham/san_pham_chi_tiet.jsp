<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh sách Sản phẩm chi tiết - Skycomputer</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --primary: #1a56db;
            --primary-light: #e6efff;
            --sidebar-active: #eef2ff;
            --text-main: #1f2937;
            --text-muted: #6b7280;
            --bg-body: #f8f9fa;
            --border-color: #e5e7eb;
            --success-text: #047857;
            --success-bg: #d1fae5;
            --danger-text: #be123c;
            --danger-bg: #ffe4e6;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            display: flex;
            height: 100vh;
            background-color: var(--bg-body);
            color: var(--text-main);
            overflow: hidden;
        }

        /* 🎨 SIDEBAR MÀU TRẮNG SÁNG */
        .sidebar {
            width: 260px;
            background-color: #fff;
            border-right: 1px solid var(--border-color);
            display: flex;
            flex-direction: column;
            height: 100vh;
            padding-bottom: 16px;
            z-index: 10;
        }

        .brand {
            display: flex;
            align-items: center;
            padding: 20px 20px;
            gap: 12px;
            border-bottom: 1px solid var(--border-color);
            margin-bottom: 12px;
        }

        .brand-logo {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.08);
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #fff;
        }

        .brand-logo img { width: 100%; height: 100%; object-fit: contain; }
        .brand-text h1 { font-size: 16px; font-weight: 700; color: #1e3a8a; margin-bottom: 0px;}
        .brand-text p { font-size: 11px; color: var(--text-muted); margin-bottom: 0; }

        .nav-menu { list-style: none; padding: 0 12px; flex: 1; overflow-y: auto; }
        .nav-item { margin-bottom: 4px; }

        .nav-link-custom {
            display: flex;
            align-items: center;
            padding: 11px 16px;
            color: var(--text-muted);
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.2s;
            gap: 12px;
        }
        .nav-link-custom i { font-size: 16px; width: 20px; text-align: center; }
        .nav-link-custom:hover { background-color: #f3f4f6; color: var(--text-main); }
        .nav-link-custom.active { background-color: var(--sidebar-active); color: var(--primary); font-weight: 600; }

        .sub-menu {
            list-style: none;
            padding-left: 0;
            margin-top: 4px;
            display: flex;
            flex-direction: column;
            gap: 2px;
        }
        .sub-menu .nav-link-custom {
            padding: 9px 16px 9px 44px !important;
            font-size: 13px;
        }
        .sub-menu .nav-link-custom.active-sub {
            background-color: var(--sidebar-active);
            color: var(--primary);
            font-weight: 600;
        }

        .logout-item { margin-top: auto; padding: 0 12px; }
        .nav-link-custom.logout-link { color: #dc2626; border-top: 1px solid var(--border-color); border-radius: 0; padding-top: 16px; }
        .nav-link-custom.logout-link:hover { background-color: var(--danger-bg); color: var(--danger-text); border-radius: 8px; }

        /* --- MAIN WRAPPER KHU VỰC BÊN PHẢI --- */
        .main-wrapper { flex: 1; display: flex; flex-direction: column; overflow: hidden; background-color: var(--bg-body); }

        .top-header {
            height: 65px;
            background-color: #fff;
            display: flex;
            align-items: center;
            padding: 0 32px;
            border-bottom: 1px solid var(--border-color);
        }
        .header-actions { display: flex; align-items: center; gap: 24px; margin-left: auto; }
        .notification { position: relative; color: var(--text-muted); cursor: pointer; font-size: 18px; }
        .notification::after { content: ''; position: absolute; top: -2px; right: 0px; width: 8px; height: 8px; background: #ef4444; border-radius: 50%; border: 2px solid #fff; }

        .user-profile { display: flex; align-items: center; gap: 12px; }
        .user-info { text-align: right; }
        .user-name { font-size: 13px; font-weight: 600; color: var(--text-main); }
        .user-role { font-size: 10px; color: var(--text-muted); text-transform: uppercase; }
        .avatar { width: 34px; height: 34px; border-radius: 50%; object-fit: cover; }

        .content-area { flex: 1; padding: 24px 32px; overflow-y: auto; }

        .content-card { background-color: #ffffff; border-radius: 12px; padding: 24px; border: 1px solid var(--border-color); box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
        .table-custom th { font-size: 12px; text-transform: uppercase; color: var(--text-muted); background-color: #f8fafc; padding: 14px; border-bottom: 1px solid var(--border-color); }
        .table-custom td { padding: 16px 14px; vertical-align: middle; font-size: 14px; border-bottom: 1px solid var(--border-color); }

        .toast-notification {
            position: fixed;
            top: 24px;
            right: 24px;
            z-index: 1050;
            min-width: 320px;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            border-radius: 8px;
            border: none;
        }

        .action-icon-btn {
            color: var(--text-muted);
            cursor: pointer;
            transition: all 0.2s ease-in-out;
            text-decoration: none;
            display: inline-block;
        }
        .action-icon-btn:hover {
            color: var(--primary);
            transform: scale(1.2);
        }
        .action-icon-btn.text-danger:hover {
            color: #dc2626 !important;
        }
    </style>
</head>
<body>

<!-- SIDEBAR -->
<aside class="sidebar">
    <div class="brand">
        <div class="brand-logo">
            <img src="${pageContext.request.contextPath}/assets/images/Logo.png" alt="Skycomputer Logo">
        </div>
        <div class="brand-text">
            <h1>Skycomputer</h1>
            <p>Hệ thống quản lý</p>
        </div>
    </div>

    <ul class="nav-menu">
        <li class="nav-item">
            <a href="${pageContext.request.contextPath}/tong-quan" class="nav-link-custom"><i class="fa-solid fa-border-all"></i> Trang tổng quan</a>
        </li>
        <li class="nav-item">
            <a href="${pageContext.request.contextPath}/hoa-don/ban-hang" class="nav-link-custom"><i class="fa-solid fa-store"></i> Bán hàng tại quầy</a>
        </li>

        <!-- DROPDOWN QUẢN LÝ SẢN PHẨM -->
        <li class="nav-item">
            <a href="#sub-san-pham" class="nav-link-custom d-flex justify-content-between align-items-center active" data-bs-toggle="collapse" role="button" aria-expanded="true">
                <span><i class="fa-solid fa-box"></i> Quản lý sản phẩm</span>
                <i class="fa-solid fa-chevron-down" style="font-size: 10px; transition: transform 0.2s;"></i>
            </a>
            <div class="collapse show" id="sub-san-pham">
                <ul class="sub-menu">
                    <li>
                        <a href="${pageContext.request.contextPath}/san-pham/hien-thi" class="nav-link-custom">
                            <i class="fa-solid fa-list me-1"></i> Danh sách sản phẩm
                        </a>
                    </li>
                    <li>
                        <a href="${pageContext.request.contextPath}/san-pham-chi-tiet/hien-thi" class="nav-link-custom active-sub">
                            <i class="fa-solid fa-circle-info me-1"></i> Sản phẩm chi tiết
                        </a>
                    </li>
                </ul>
            </div>
        </li>

        <!-- QUẢN LÝ HÓA ĐƠN -->
        <li class="nav-item">
            <a href="${pageContext.request.contextPath}/hoa-don/hien-thi" class="nav-link-custom"><i class="fa-solid fa-file-invoice"></i> Quản lý hóa đơn</a>
        </li>

        <!-- QUẢN LÝ KHÁCH HÀNG -->
        <li class="nav-item">
            <a href="${pageContext.request.contextPath}/khach-hang/hien-thi" class="nav-link-custom"><i class="fa-solid fa-users"></i> Quản lý khách hàng</a>
        </li>

        <!-- QUẢN LÝ NHÂN VIÊN -->
        <li class="nav-item">
            <a href="${pageContext.request.contextPath}/nhan-vien/hien-thi" class="nav-link-custom"><i class="fa-solid fa-id-badge"></i> Quản lý nhân viên</a>
        </li>

        <li class="nav-item">
            <a href="${pageContext.request.contextPath}/phieu-giam-gia/hien-thi" class="nav-link-custom"><i class="fa-solid fa-ticket"></i> Quản lý phiếu giảm giá</a>
        </li>

        <!-- DROPDOWN QUẢN LÝ THUỘC TÍNH -->
        <li class="nav-item">
            <a href="#sub-thuoc-tinh" class="nav-link-custom d-flex justify-content-between align-items-center" data-bs-toggle="collapse" role="button" aria-expanded="false">
                <span><i class="fa-solid fa-sliders"></i> Quản lý thuộc tính</span>
                <i class="fa-solid fa-chevron-down" style="font-size: 10px; transition: transform 0.2s;"></i>
            </a>
            <div class="collapse" id="sub-thuoc-tinh">
                <ul class="sub-menu">
                    <li><a href="${pageContext.request.contextPath}/thuoc-tinh/cpu/hien-thi" class="nav-link-custom"><i class="fa-solid fa-microchip me-1"></i> Cấu hình CPU</a></li>
                    <li><a href="${pageContext.request.contextPath}/thuoc-tinh/ram/hien-thi" class="nav-link-custom"><i class="fa-solid fa-memory me-1"></i> Cấu hình RAM</a></li>
                    <li><a href="${pageContext.request.contextPath}/thuoc-tinh/o-cung/hien-thi" class="nav-link-custom"><i class="fa-solid fa-hard-drive me-1"></i> Ổ cứng</a></li>
                    <li><a href="${pageContext.request.contextPath}/thuoc-tinh/gpu/hien-thi" class="nav-link-custom"><i class="fa-solid fa-clone me-1"></i> Card đồ họa (GPU)</a></li>
                    <li><a href="${pageContext.request.contextPath}/thuoc-tinh/man-hinh/hien-thi" class="nav-link-custom"><i class="fa-solid fa-display me-1"></i> Màn hình</a></li>
                    <li><a href="${pageContext.request.contextPath}/thuoc-tinh/mau-sac/hien-thi" class="nav-link-custom"><i class="fa-solid fa-palette me-1"></i> Màu sắc</a></li>
                    <li><a href="${pageContext.request.contextPath}/thuoc-tinh/pin/hien-thi" class="nav-link-custom"><i class="fa-solid fa-battery-three-quarters me-1"></i> Thông số Pin</a></li>
                    <li><a href="${pageContext.request.contextPath}/thuoc-tinh/danh-muc/hien-thi" class="nav-link-custom"><i class="fa-solid fa-layer-group me-1"></i> Danh mục sản phẩm</a></li>
                    <li><a href="${pageContext.request.contextPath}/thuoc-tinh/thuong-hieu/hien-thi" class="nav-link-custom"><i class="fa-solid fa-copyright me-1"></i> Thương hiệu</a></li>
                </ul>
            </div>
        </li>
    </ul>

    <div class="logout-item">
        <a href="${pageContext.request.contextPath}/dang-xuat" class="nav-link-custom logout-link">
            <i class="fa-solid fa-arrow-right-from-bracket"></i> Đăng xuất
        </a>
    </div>
</aside>

<main class="main-wrapper">
    <header class="top-header">
        <div class="header-actions">
            <div class="notification"><i class="fa-regular fa-bell"></i></div>
            <div class="user-profile">
                <div class="user-info">
                    <div class="user-name">Admin User</div>
                    <div class="user-role">QUẢN TRỊ VIÊN</div>
                </div>
                <img src="https://i.pravatar.cc/150?img=11" alt="Avatar" class="avatar">
            </div>
        </div>
    </header>

    <div class="content-area">
        <c:if test="${not empty sessionScope.successMessage}">
            <div class="alert alert-success alert-dismissible fade show toast-notification" role="alert">
                    ${sessionScope.successMessage}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <c:remove var="successMessage" scope="session" />
        </c:if>

        <c:if test="${not empty sessionScope.errorMessage}">
            <div class="alert alert-danger alert-dismissible fade show toast-notification" role="alert">
                    ${sessionScope.errorMessage}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <c:remove var="errorMessage" scope="session" />
        </c:if>

        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="fw-bold mb-1" style="color: var(--text-main);">Quản lý Biến thể Sản phẩm</h4>
                <small class="text-muted">Danh sách các phiên bản cấu hình thương mại trong kho</small>
            </div>
            <a href="${pageContext.request.contextPath}/san-pham/giao-dien-them" class="btn btn-primary px-4 py-2" style="border-radius: 8px; font-weight: 500; font-size: 14px;">
                <i class="fa-solid fa-plus me-2"></i>Thêm biến thể mới
            </a>
        </div>

        <div class="content-card">
            <table class="table table-custom align-middle">
                <thead>
                <tr>
                    <th style="width: 50px;">STT</th>
                    <th>Tên SP Cha</th>
                    <th>Màu Sắc</th>
                    <th>RAM</th>
                    <th>Ổ Cứng</th>
                    <th>Giá Bán</th>
                    <th>Tồn Kho</th>
                    <th class="text-center" style="width: 120px;">Thao Tác</th>
                </tr>
                </thead>
                <tbody>
                <c:forEach items="${listChiTiet}" var="ct" varStatus="stt">
                    <tr>
                        <td class="text-muted fw-semibold">${stt.index + 1}</td>
                        <td class="fw-bold text-dark">${ct.sanPham.tenSanPham}</td>
                        <td><span class="badge border text-dark bg-light px-2 py-1"><i class="fa-solid fa-circle me-1 text-secondary" style="font-size:8px;"></i>${ct.cauHinhSanPham.mauSac.tenMauSac}</span></td>
                        <td class="fw-medium">${ct.cauHinhSanPham.ram.dungLuongRam}</td>
                        <td class="fw-medium">${ct.cauHinhSanPham.OCung.dungLuongOCung}</td>
                        <td class="text-success fw-bold"><fmt:formatNumber value="${ct.donGia}" type="currency" currencySymbol="₫"/></td>
                        <td><span class="badge bg-success px-2 py-1">${ct.tonKho}</span></td>

                        <!-- 🟢 ĐÃ ĐỔI THÀNH ICON THUẦN TÚY CÙNG MÀU MENU CHỦ ĐẠO -->
                        <td class="text-center">
                            <div class="d-flex justify-content-center gap-3 align-items-center">
                                <!-- ICON XEM DETAIL -->
                                <a href="${pageContext.request.contextPath}/san-pham-chi-tiet/detail?id=${ct.id}" title="Xem chi tiết biến thể & IMEI" class="action-icon-btn">
                                    <i class="fa-regular fa-eye fs-5"></i>
                                </a>

                                <!-- ICON XÓA / ĐỔI TRẠNG THÁI -->
                                <form action="${pageContext.request.contextPath}/san-pham-chi-tiet/xoa" method="POST" id="formDelete-${ct.id}" style="margin:0;">
                                    <input type="hidden" name="id" value="${ct.id}">
                                    <i class="fa-regular fa-trash-can fs-5 action-icon-btn text-danger" title="Xóa bản ghi này"
                                       onclick="if(confirm('Bạn có chắc chắn muốn xóa bản ghi này không?')) document.getElementById('formDelete-${ct.id}').submit();">
                                    </i>
                                </form>
                            </div>
                        </td>
                    </tr>
                </c:forEach>
                <c:if test="${empty listChiTiet}">
                    <tr><td colspan="8" class="text-center py-5 text-muted">Kho hàng biến thể trống!</td></tr>
                </c:if>
                </tbody>
            </table>
        </div>
    </div>
</main>

<!-- POPUP MODAL XEM CHI TIẾT (AJAX) -->
<div class="modal fade" id="detailSkuyModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 12px;">
            <div class="modal-header border-0 pt-4 px-4 pb-2">
                <h5 class="modal-title fw-bold text-dark" style="font-size: 16px;">
                    <i class="fa-solid fa-circle-info text-dark me-2"></i>Chi tiết cấu hình biến thể
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body px-4 pb-4">
                <div class="row g-4">
                    <div class="col-md-7">
                        <div class="p-3 bg-light rounded-3 h-100 border">
                            <h6 class="fw-bold text-dark mb-3 small"><i class="fa-solid fa-microchip me-2 text-primary"></i>THÔNG SỐ KỸ THUẬT</h6>
                            <table class="table table-sm table-borderless mb-0" style="font-size: 13px;">
                                <tr><td class="text-muted py-1.5" style="width: 130px;">Tên sản phẩm:</td><td class="fw-semibold text-dark py-1.5" id="lblDetTen">...</td></tr>
                                <tr><td class="text-muted py-1.5">Mã SKU:</td><td class="fw-bold text-danger py-1.5" id="lblDetSku">...</td></tr>
                                <tr><td class="text-muted py-1.5">Bộ vi xử lý (CPU):</td><td class="text-dark py-1.5" id="lblDetCpu">...</td></tr>
                                <tr><td class="text-muted py-1.5">Bộ nhớ RAM:</td><td class="text-dark py-1.5" id="lblDetRam">...</td></tr>
                                <tr><td class="text-muted py-1.5">Ổ cứng SSD:</td><td class="text-dark py-1.5" id="lblDetOcung">...</td></tr>
                                <tr><td class="text-muted py-1.5">Card đồ họa (GPU):</td><td class="text-dark py-1.5" id="lblDetGpu">...</td></tr>
                                <tr><td class="text-muted py-1.5">Màn hình:</td><td class="text-dark py-1.5" id="lblDetManHinh">...</td></tr>
                                <tr><td class="text-muted py-1.5">Màu sắc:</td><td class="text-dark py-1.5" id="lblDetMau">...</td></tr>
                                <tr><td class="text-muted py-1.5">Giá bán niêm yết:</td><td class="fw-bold text-success py-1.5" id="lblDetGia">...</td></tr>
                            </table>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="p-3 bg-light rounded-3 h-100 border d-flex flex-column">
                            <h6 class="fw-bold text-dark mb-2 small"><i class="fa-solid fa-barcode me-2 text-success"></i>DANH SÁCH IMEI TỒN KHO</h6>
                            <small class="text-muted mb-2 d-block">Tổng số máy trong kho: <span class="fw-bold text-dark" id="lblDetTotalImei">0</span></small>
                            <div class="flex-grow-1 overflow-y-auto pe-1" id="boxDetImeiList" style="max-height: 240px;"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer border-0 px-4 pb-4 pt-0">
                <button type="button" class="btn btn-secondary px-4 btn-sm py-2" data-bs-dismiss="modal" style="border-radius:6px;">Đóng</button>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        setTimeout(function() {
            let alertNode = document.querySelector('.toast-notification');
            if (alertNode) {
                let bsAlert = new bootstrap.Alert(alertNode);
                bsAlert.close();
            }
        }, 3000);
    });

    function moPopupXemChiTiet(idChiTiet) {
        $.ajax({
            url: "${pageContext.request.contextPath}/san-pham-chi-tiet/detail-json",
            type: "GET",
            data: { id: idChiTiet },
            success: function(res) {
                if (res.status === "success") {
                    $("#lblDetTen").text(res.tenSanPham || "N/A");
                    $("#lblDetSku").text("#" + (res.maSku || "N/A"));
                    $("#lblDetCpu").text(res.tenCpu || "N/A");
                    $("#lblDetRam").text(res.dungLuongRam || "N/A");
                    $("#lblDetOcung").text(res.dungLuongOCung || "N/A");
                    $("#lblDetGpu").text(res.tenGpu || "N/A");
                    $("#lblDetManHinh").text(res.tenManHinh || "N/A");
                    $("#lblDetMau").text(res.tenMauSac || "N/A");

                    if (res.giaBan) {
                        $("#lblDetGia").text(res.giaBan.toLocaleString('vi-VN') + " ₫");
                    } else {
                        $("#lblDetGia").text("0 ₫");
                    }

                    let countImei = res.listImei ? res.listImei.length : 0;
                    $("#lblDetTotalImei").text(countImei);

                    let htmlImei = "";
                    if (res.listImei && countImei > 0) {
                        res.listImei.forEach(function(item) {
                            htmlImei += '<div class="p-2 bg-white border rounded mb-1 font-monospace small d-flex justify-content-between align-items-center" style="border-radius: 6px;">' +
                                '<span><i class="fa-solid fa-laptop text-muted me-2"></i>' + item.soSeri + '</span>' +
                                '<span class="badge bg-success-subtle text-success border border-success-subtle px-1.5 py-0.5" style="font-size:10px;">Trong kho</span>' +
                                '</div>';
                        });
                    } else {
                        htmlImei = '<div class="text-center text-muted small py-4">Biến thể cấu hình này hiện tại đã hết hàng!</div>';
                    }
                    $("#boxDetImeiList").html(htmlImei);

                    const modalEl = document.getElementById('detailSkuyModal');
                    bootstrap.Modal.getOrCreateInstance(modalEl).show();
                } else {
                    alert("Lỗi từ hệ thống: " + res.message);
                }
            },
            error: function(xhr) {
                alert("Không thể tải dữ liệu chi tiết, vui lòng kiểm tra lại đường dẫn API mapping ở Servlet!");
            }
        });
    }
</script>
</body>
</html>